C:\Users\anzki\Downloads\project1-20260622T193713Z-3-001\project1\Reciver\sketch_jun3a\build_csv_transfer\core\libb64\cencode.c.o: \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5\cores\esp32\libb64\cencode.c \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5\cores\esp32\libb64\cencode.h
