C:\Users\anzki\Downloads\project1-20260622T193713Z-3-001\project1\Reciver\sketch_jun3a\build_csv_transfer\core\double_tap.c.o: \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5\variants\arduino_nano_nora\double_tap.c \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_system/include/esp_system.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_common/include/esp_err.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_common/include/esp_compiler.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_common/include/esp_attr.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_common/include/esp_bit_defs.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_common/include/esp_idf_version.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_hw_support/include/esp_mac.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_hw_support/include/esp_chip_info.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_hw_support/include/esp_random.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_rom/include/esp32s3/rom/cache.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/heap/include/esp_heap_caps.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/heap/include/multi_heap.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5\variants\arduino_nano_nora\double_tap.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/soc/esp32s3/include/soc/soc.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_common/include/esp_assert.h
