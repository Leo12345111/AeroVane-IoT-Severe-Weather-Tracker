C:\Users\anzki\Downloads\project1-20260622T193713Z-3-001\project1\Reciver\sketch_jun3a\build_csv_transfer\core\stdlib_noniso.c.o: \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5\cores\esp32\stdlib_noniso.c \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5\cores\esp32\stdlib_noniso.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_system/include/esp_system.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_common/include/esp_err.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_common/include/esp_compiler.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_common/include/esp_attr.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_common/include/esp_bit_defs.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_common/include/esp_idf_version.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_hw_support/include/esp_mac.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_hw_support/include/esp_chip_info.h \
 C:\Users\anzki\AppData\Local\Arduino15\packages\arduino\hardware\esp32\2.0.18-arduino.5/tools/sdk/esp32s3/include/esp_hw_support/include/esp_random.h
