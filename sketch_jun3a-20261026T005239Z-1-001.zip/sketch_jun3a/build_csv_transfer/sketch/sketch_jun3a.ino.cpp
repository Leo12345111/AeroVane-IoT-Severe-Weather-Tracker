#line 1 "C:\\Users\\anzki\\Downloads\\project1-20260622T193713Z-3-001\\project1\\Reciver\\sketch_jun3a\\sketch_jun3a.ino"
#include <Arduino.h>
#include <SPI.h>
#include <LoRa.h>

// Arduino Nano ESP32 receiver wiring from the supplied receiver schematic.
constexpr uint8_t LORA_SCK_PIN = D13;
constexpr uint8_t LORA_MISO_PIN = D12;
constexpr uint8_t LORA_MOSI_PIN = D11;
constexpr uint8_t LORA_CS_PIN = D10;
constexpr uint8_t LORA_RST_PIN = D9;
constexpr uint8_t LORA_DIO0_PIN = D7;

constexpr long LORA_FREQUENCY_HZ = 915000000L;
constexpr uint8_t LORA_SPREADING_FACTOR = 8;
constexpr long LORA_BANDWIDTH_HZ = 125000L;
constexpr uint8_t LORA_CODING_RATE = 5;
constexpr uint16_t LORA_PREAMBLE_LENGTH = 12;
constexpr uint8_t LORA_SYNC_WORD = 0x34;
constexpr int8_t LORA_TX_POWER_DBM = 17;
constexpr uint8_t COMMAND_REPEATS = 3;
constexpr uint16_t COMMAND_REPEAT_DELAY_MS = 180;

const char ROCKET_ID[] = "1333877";
bool radioReady = false;

#line 26 "C:\\Users\\anzki\\Downloads\\project1-20260622T193713Z-3-001\\project1\\Reciver\\sketch_jun3a\\sketch_jun3a.ino"
bool initializeRadio();
#line 49 "C:\\Users\\anzki\\Downloads\\project1-20260622T193713Z-3-001\\project1\\Reciver\\sketch_jun3a\\sketch_jun3a.ino"
void receiveTelemetry();
#line 84 "C:\\Users\\anzki\\Downloads\\project1-20260622T193713Z-3-001\\project1\\Reciver\\sketch_jun3a\\sketch_jun3a.ino"
bool transmitCommand(const String &command);
#line 103 "C:\\Users\\anzki\\Downloads\\project1-20260622T193713Z-3-001\\project1\\Reciver\\sketch_jun3a\\sketch_jun3a.ino"
void handleDashboardCommand();
#line 127 "C:\\Users\\anzki\\Downloads\\project1-20260622T193713Z-3-001\\project1\\Reciver\\sketch_jun3a\\sketch_jun3a.ino"
void setup();
#line 144 "C:\\Users\\anzki\\Downloads\\project1-20260622T193713Z-3-001\\project1\\Reciver\\sketch_jun3a\\sketch_jun3a.ino"
void loop();
#line 26 "C:\\Users\\anzki\\Downloads\\project1-20260622T193713Z-3-001\\project1\\Reciver\\sketch_jun3a\\sketch_jun3a.ino"
bool initializeRadio() {
  pinMode(LORA_CS_PIN, OUTPUT);
  digitalWrite(LORA_CS_PIN, HIGH);
  SPI.begin(LORA_SCK_PIN, LORA_MISO_PIN, LORA_MOSI_PIN, LORA_CS_PIN);
  LoRa.setSPI(SPI);
  LoRa.setPins(LORA_CS_PIN, LORA_RST_PIN, LORA_DIO0_PIN);

  if (!LoRa.begin(LORA_FREQUENCY_HZ)) {
    Serial.println("LORA ERROR: RFM95 initialization failed.");
    return false;
  }

  LoRa.setSpreadingFactor(LORA_SPREADING_FACTOR);
  LoRa.setSignalBandwidth(LORA_BANDWIDTH_HZ);
  LoRa.setCodingRate4(LORA_CODING_RATE);
  LoRa.setPreambleLength(LORA_PREAMBLE_LENGTH);
  LoRa.setSyncWord(LORA_SYNC_WORD);
  LoRa.enableCrc();
  LoRa.setTxPower(LORA_TX_POWER_DBM);
  LoRa.receive();
  return true;
}

void receiveTelemetry() {
  if (!radioReady) {
    return;
  }

  const int packetSize = LoRa.parsePacket();
  if (packetSize <= 0) {
    return;
  }

  String payload;
  payload.reserve(packetSize);
  while (LoRa.available()) {
    payload += static_cast<char>(LoRa.read());
  }
  const bool isTelemetry = payload.startsWith("RT2,");
  const bool isCsvTransfer = payload.startsWith("CSV_DUMP_BEGIN,") ||
                             payload.startsWith("CSV_DUMP_ROW,") ||
                             payload.startsWith("CSV_DUMP_END,");
  if (!isTelemetry && !isCsvTransfer) {
    Serial.print("Ignored unsupported packet: ");
    Serial.println(payload);
    LoRa.receive();
    return;
  }

  Serial.print("Received packet: \"");
  Serial.print(payload);
  Serial.print("\" with RSSI: ");
  Serial.print(LoRa.packetRssi());
  Serial.print(" SNR: ");
  Serial.println(LoRa.packetSnr());
  LoRa.receive();
}

bool transmitCommand(const String &command) {
  if (!radioReady || command.length() == 0 || command.length() > 255) {
    return false;
  }

  bool sent = false;
  for (uint8_t attempt = 0; attempt < COMMAND_REPEATS; ++attempt) {
    LoRa.idle();
    LoRa.beginPacket();
    LoRa.print(command);
    sent = (LoRa.endPacket() == 1) || sent;
    LoRa.receive();
    if (attempt + 1 < COMMAND_REPEATS) {
      delay(COMMAND_REPEAT_DELAY_MS);
    }
  }
  return sent;
}

void handleDashboardCommand() {
  if (!Serial.available()) {
    return;
  }

  String command = Serial.readStringUntil('\n');
  command.trim();
  if (command.length() == 0) {
    return;
  }
  command.replace('\r', ' ');
  command.replace('\n', ' ');
  if (!command.startsWith("CMD:")) {
    command = "CMD:" + command;
  }

  if (transmitCommand(command)) {
    Serial.print("Sent command to payload (3 copies): ");
  } else {
    Serial.print("Command TX failed: ");
  }
  Serial.println(command);
}

void setup() {
  Serial.begin(115200);
  Serial.setTimeout(40);
  const uint32_t waitStarted = millis();
  while (!Serial && millis() - waitStarted < 3000) {
    delay(10);
  }

  Serial.println(ROCKET_ID);
  Serial.println("Initializing production RFM95 receiver...");
  radioReady = initializeRadio();
  Serial.println(
    radioReady
      ? "Receiver ready: 915MHz SF8 BW125 CR4/5 P12 CRC."
      : "Receiver radio failed; check 3.3V and SPI wiring.");
}

void loop() {
  receiveTelemetry();
  handleDashboardCommand();
  delay(1);
}

